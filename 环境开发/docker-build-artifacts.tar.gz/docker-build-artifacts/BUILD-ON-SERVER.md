# Build On Server

```bash
cd docker-build-artifacts
docker build -f Dockerfile.ai-courses-optimized -t opencode-lab-ai:latest .
docker run -d -p 2222:22 -p 5901:5901 -p 6080:6080 --name ai-lab opencode-lab-ai:latest
./setup-api-keys.sh
./test-courses-quick.sh
```
