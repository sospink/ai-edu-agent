# OpenCode Lab AI 课程实验环境

基于 Ubuntu 22.04 的 AI 课程实验镜像，集成 SSH、VNC 桌面、OpenCode AI，并升级为 `new-course/Agent` 课程资源。

## 课程资源（主目录）

容器内主目录：`/workspace/new-course/Agent`

包含 5 份可用课程资源：

1. `ADE_Agent` - ADE 配置与智能体开发
2. `MCP_Server` - MCP Server 开发
3. `AgentFramework` - 智能体框架与开发（单 Agent）
4. `MultiAgentFramework/brainstorm-mas` - 智能体框架与开发（多 Agent）
5. `SecurityGuardrails/bartender-guardrails` - 安全与合规

## 兼容路径

为兼容平台旧路径，镜像内保留 `/workspace/courses/*` 映射：

- `/workspace/courses/ade-skill` -> `ADE_Agent`
- `/workspace/courses/mcp-server` -> `MCP_Server`
- `/workspace/courses/agent-gordon` -> `AgentFramework`
- `/workspace/courses/multi-agent` -> `MultiAgentFramework/brainstorm-mas`
- `/workspace/courses/guardrails` -> `SecurityGuardrails/bartender-guardrails`

## 快速开始

### 1. 构建镜像

```bash
cd 环境开发
docker build -f Dockerfile.ai-courses-optimized -t opencode-lab-ai:latest .
```

### 2. 运行容器

```bash
docker run -d \
  -p 2222:22 \
  -p 5901:5901 \
  -p 6080:6080 \
  --name ai-lab \
  opencode-lab-ai:latest
```

### 3. 配置 API + 快速测试

```bash
cd 环境开发
chmod +x quick-start-rebuilt.sh
./quick-start-rebuilt.sh
```

或分步执行：

```bash
./setup-api-keys.sh
./test-courses-quick.sh
```

## 访问方式

- noVNC: `http://localhost:6080`
- SSH: `ssh root@localhost -p 2222`（密码：`opencode`）

## API 环境变量（统一）

镜像内 `.env` 路径：`/workspace/.env`

建议至少配置：

```env
ZHIPUAI_API_KEY=your-key
ZHIPU_API_KEY=your-key
OPENAI_API_KEY=your-key
OPENAI_BASE_URL=https://open.bigmodel.cn/api/paas/v4
OPENAI_MODEL=glm-4-flash
```

> `setup-api-keys.sh` 会自动从 `../EDU_Backend/.env` 读取并生成这些变量。

## 课程运行示例

```bash
# 单 Agent
docker exec -it ai-lab bash -lc "cd /workspace/new-course/Agent/AgentFramework && python3 main.py --demo"

# 多 Agent
docker exec -it ai-lab bash -lc "cd /workspace/new-course/Agent/MultiAgentFramework/brainstorm-mas && python3 main.py --demo"

# MCP Server
docker exec -it ai-lab bash -lc "cd /workspace/new-course/Agent/MCP_Server && node dist/index.js"

# Guardrails
docker exec -it ai-lab bash -lc "cd /workspace/new-course/Agent/SecurityGuardrails/bartender-guardrails && python3 main.py --demo"
```

## 常用命令

```bash
# 查看日志
docker logs ai-lab

# 进入容器
docker exec -it ai-lab bash

# 停止/启动容器
docker stop ai-lab
docker start ai-lab
```
